# 🐾 MAGLU Pet Center - Adoção de Pets

Site escolar de adoção de pets com catálogo filtrável, quiz de indicação e
formulário que encaminha o interesse para o WhatsApp da equipe.

## 📂 Estrutura de arquivos
```
maglu-pet-center/
├── index.html          # home: hero + catálogo com filtros
├── quiz.html           # quiz de adoção
├── contato.html        # formulário "quero adotar"
├── estilo/
│   └── styles.css      # estilos de TODAS as páginas
├── js/
│   ├── script.js       # menu mobile, ano do rodapé e catálogo (comum a todas)
│   ├── quiz.js         # lógica do quiz
│   ├── contato.js      # máscaras, validação e envio do formulário
│   └── server.js       # servidor Express + link do WhatsApp
└── imagens/            # banner e fotos dos pets
```

## ▶️ Como executar
As páginas abrem direto no navegador, mas o **formulário de contato precisa do servidor**:

```bash
npm install express
node js/server.js
# acesse http://localhost:3000
```

Defina o número de atendimento antes de publicar:
```bash
WHATSAPP_ATENDIMENTO=5511999999999 node js/server.js
```

## 🎯 Conceitos abordados
- HTML semântico (`header`, `main`, `section`, `article`, `footer`)
- Meta tags, acessibilidade básica (foco visível, `aria-*`) e SEO
- CSS moderno: variáveis, Flexbox, Grid, transições e media queries
- Layout responsivo com menu mobile
- JavaScript: DOM, eventos, filtro dinâmico, máscaras e validação
- Node.js/Express: arquivos estáticos, rota POST e validação no servidor

## 💡 Exercícios sugeridos
1. Campo de busca por nome (`input` + `filter`).
2. Ordenar o catálogo por nome ou idade com `array.sort()`.
3. Salvar o filtro ativo no `localStorage` e restaurar ao recarregar.
4. Carregar os pets de um `dados.json` com `fetch`.
5. Paginação do catálogo (4 pets por página).
